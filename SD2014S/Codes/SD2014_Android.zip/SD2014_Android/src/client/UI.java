package client;

public interface UI {
    public void init();
}
