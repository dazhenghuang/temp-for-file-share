package client;

public interface Connection {
	
	public boolean openConnection();
	public boolean closeConnection();

}
