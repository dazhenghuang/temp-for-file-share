package com.master.TPM;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.List;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
//import javax.swing.JOptionPane;

import net.sf.lipermi.net.Server;
import net.sf.lipermi.exception.LipeRMIException;
import net.sf.lipermi.handler.*;

import com.master.TPM.AndroidSecurityInt;

/**
 * 
 * @author Caleb Schwind
 *
 */
public class AndroidSecurity implements AndroidSecurityInt {
		boolean isIndex = false; // index file flag
	    String rootDir = "//mnt//extsd//";
	    String ivDir = "//mnt//extsd//ivs//";
		//String bulksPath = "C:\\Users\\Caleb\\SeniorDesign\\bulks\\";
	   // String piecePath = "C:\\Users\\Caleb\\SeniorDesign\\pieces\\";
	    //String tempPath = "C:\\Users\\Caleb\\SeniorDesign\\temp\\";
	    //String IVs = "C:\\Users\\Caleb\\SeniorDesign\\ivs\\";
	    //String outputDir = "C:\\Users\\Caleb\\SeniorDesign\\decrypted\\";
		
	    private static Server server;

		
		/**Encrypts the message or obfuscated password
		 * 
		 * @param obfuscated message or password
		 * @param encryption key
		 * @param IV output filename
		 * @return encrypted message or obfuscated password
		 */
		public byte[] encryptMessage(byte[] message, SecretKey key, String ivOut) {
			Encrypt encrypt = new Encrypt(key, ivDir + ivOut);
			
			//Encrypt the message
			byte[] encryptedMessage = encrypt.encrypt(message);
			
			return encryptedMessage;
		}
		
		/**Decrypts messages or the obfuscated password
		 * 
		 * @param encrypted message or obfuscated password
		 * @param decryption key
		 * @param filename of the IV
		 * @return decrypted message or obfuscated password
		 */
		public byte[] decryptMessage(byte[] encrMessage, SecretKey key, String ivIn, boolean isIV) {
			Decrypt decrypt;
			
			if (isIV) {
				decrypt = new Decrypt(key, ivIn, true);
			}	else {
				decrypt = new Decrypt(key, ivDir + ivIn, false);
			}
			//decrypt the message
			byte[] decryptedMessage = decrypt.decrypt(encrMessage);
			
			return decryptedMessage;
		}

		
		public SecretKey getSecureChannelKey(byte[] seed1, byte[] seed2, String pressedKey) {
			byte[] seed = new byte[seed1.length];			
		
			// XORs the two generated seeds
			for(int i = 0; i < seed1.length; i++) {
				seed[i] = (byte) (seed1[i] ^ seed2[i]);
			}
			
			byte[] pressedKeyBytes = pressedKey.getBytes();
			byte[] tempKey = new byte[seed.length + pressedKeyBytes.length];
 	    	System.arraycopy(seed, 0, tempKey, 0, seed.length);
 	    	System.arraycopy(pressedKeyBytes, 0, tempKey, seed.length, pressedKeyBytes.length);
			System.out.println(tempKey.length);
			byte[] newKey = new byte[16];
			
			//get 16 random bytes
			int getByte = 0;
			for (int i = 0; i < 16; i++) {
				getByte = (int)(Math.random() * (seed.length + pressedKeyBytes.length));
				newKey[i] = tempKey[getByte];
			}
 	    	System.out.println("test loop");
			//create key from xored seeds
			SecretKey seedKey = new SecretKeySpec(newKey, "AES");
			
			//Create secure channel encryption key
			Encrypt encrypt = new Encrypt(seedKey); //encrypts a string of 0s
			byte[] tempEncr1 = encrypt.encrypt("0000000000000000".getBytes());
			byte[] tempEncr2 = encrypt.encrypt(tempEncr1);
			
			byte[] connectionKeyBytes = new byte[16];
			
			//get 16 random bytes
			for (int i = 0; i < 16; i++) {
				getByte = (int)(Math.random() * (tempEncr2.length + 1));
				connectionKeyBytes[i] = tempKey[getByte];
			}
			
			SecretKey connectionKey = new SecretKeySpec(connectionKeyBytes, "AES");
		//	String connectionKey = new String(connectionKeyBytes, 
			
			return connectionKey;
		}
		
		/**
		 * Generates a random key as byte array
		 * @return random key as byte array
		 */
		public byte[] getRandomKey() {
			long salt = 0;
			Random random = null;
			byte [] testrngrn = null;
			//sets the Random object to use SHA1PRNG
			try {
				random = SecureRandom.getInstance("SHA1PRNG");
			
				//gets the time of day in nanoseconds
				long nanoGMT2 = System.nanoTime();
			
				//loops through several times to get a random salt
				for (int i=0; i<2; i++) {
					//sets the random generator seed to the current time
					random.setSeed(nanoGMT2);
					nanoGMT2 = System.nanoTime();
					
					//sets the salt value
					salt = random.nextLong();	
				}
				
				//loops through several times to get a random key
				for (int i=0; i<2; i++) {
					// sets the random generator seed to the current time plus
					// the salt/password combination
					random.setSeed(nanoGMT2+salt);
					nanoGMT2 = System.nanoTime();
					
					// stores the random 16 byte array
					testrngrn = new byte [16];
					random.nextBytes(testrngrn);
				}
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// returns the random array produced
			return testrngrn;
		}
		
		/**
		 * Compares two obfuscated passwords and returns true if they macth or false
		 * if they don't.
		 * 
		 * @param The stored password from last login
		 * @param The password received from attempted login
		 * @return is password correct 
		 */
		public boolean authenticate(byte[] pass1, byte[] testPass) {
			String pass1St = "";
			String pass2St = "";
			
			try {
				//Convert the byte[]s to strings
				pass1St = new String(pass1, "UTF-8");
				pass2St = new String(testPass, "UTF-8");
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if (pass1St.equals(pass2St)) {
				return true; //Passwords match
			} else {
				return false; //Passwords don't match
			}
		}
	
		/**
		 * Writes the seeds to USB/SD
		 * 
		 * @param current login seed
		 * @param next login seed
		 * @param filename + path to save seeds
		 */
		public void writeSeeds(byte[] seed1, byte[] seed2, String filename) {
			try {
				String seeds = new String(seed1, "UTF-8") + "," + new String(seed2, "UTF-8");
				File seedFile = new File(rootDir + "seeds.txt");
				//File cloudSeedFile = new File("C:\\Users\\Caleb\\SkyDrive\\seeds.txt");
				BufferedWriter out = new BufferedWriter(new FileWriter(seedFile));
				//BufferedWriter cloudOut = new BufferedWriter(new FileWriter(seedFile));
				out.write(seeds);
				//cloudOut.write(seeds);
				out.close();
				//cloudOut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/**
		 * Gets the seeds from the USB/SD.
		 * 
		 * @param filename + path to read seeds
		 * @return seeds seperated by a comma
		 */
		public String getSeeds(String filename) {
			String seeds = "";
			seeds = readLine(filename);
			
			return seeds;
		}
		
		/**
		 * Converts long to byte[] for dealing with seeds of long type.
		 * 
		 * @param seed of type long
		 * @return seed of type byte[]
		 */
		public byte[] long2byte(long l) 
	    {
			byte[] bytes = null;
			ByteBuffer buffer = ByteBuffer.allocate(8);
			buffer.putLong(l);
			bytes = buffer.array();
		    
			return bytes;    
	    }
		
		
		
/**
		 * reads a line from the input file
		 * @param fileName to read from
		 * @return line read from the file
		 */
		public String readLine(String fileName) 
	    {
			String strLine = "";
	    	try{
	    		//reads the line from the file
	    		  FileInputStream fstream = new FileInputStream(ivDir + fileName);
	    		  // Get the object of DataInputStream
	    		  DataInputStream in = new DataInputStream(fstream);
	    		  BufferedReader br = new BufferedReader(new InputStreamReader(in));
	    		  strLine = br.readLine();
	    		  
	    		  //Close the input stream
	    		  in.close();
	    	}
	    	//Catch exception if any
	    	catch (Exception e)
	    	{
	    		  System.err.println("Error: " + e.getMessage());
	    	}
	    	
	    	return strLine;
	    }
		
		 /**
		  * reads the bytes from a file
		  * @param file to get bytes from
		  * @return bytes from the file
		  * @throws IOException
		  */
		 private static byte[] getBytesFromFile(File file) throws IOException {
	      InputStream is = new FileInputStream(file);
	  
	      // Get the size of the file
	      long length = file.length();
	  
	      if (length > Integer.MAX_VALUE) {
	          // File is too large
	      }
	  
	      // Create the byte array to hold the data
	      byte[] bytes = new byte[(int)length];
	  
	      // Read in the bytes
	      int offset = 0;
	      int numRead = 0;
	      while (offset < bytes.length
	             && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	          offset += numRead;
	      }
	  
	      // Ensure all the bytes have been read in
	      if (offset < bytes.length) {
	          extracted(file);
	      }
	  
	      // Close the input stream and return bytes
	      is.close();
	      return bytes;
	  }
		 
		   /**
		    * reads the contents of a file
		    * @param fileName to read
		    * @return content read from the file
		    * @throws IOException
		    */
			private static String readFile(String fileName) throws IOException 
		    {
		    	String output = "";
		    	try{
		    		//opens file to be read
		    		  FileInputStream fstream = new FileInputStream(fileName);
		    		  // Get the object of DataInputStream
		    		  DataInputStream in = new DataInputStream(fstream);
		    		  BufferedReader br = new BufferedReader(new InputStreamReader(in));
		    		  String strLine;
		    		  
		    		  //Read File Line By Line
		    		  while ((strLine = br.readLine()) != null)   {
			    		  output += strLine;
			    		  output += "\n";
		    		  }
		    		  
		    		  //Close the input stream
		    		  in.close();
		    	}
		    	//Catch exception if any
		    	catch (Exception e)
		    	{
		    		  System.err.println("Error: " + e.getMessage());
		    	}
		    	
		    	//returns contents of file
		    	return output;
		    }
		 
		/**
		 * checks that the entire file was read
		 * @param file
		 * @throws IOException
		 */
		private static void extracted(File file) throws IOException {
			throw new IOException("Could not completely read file "+file.getName());
		}
		
		/**
		 * converts the input hex string into a byte array
		 * @param input
		 * @return byte version of the key
		 */
		private static byte[] keyFromHex(String input) {
		    
			int len = input.length();
		    byte[] bKey = new byte[len / 2];
		    for (int i = 0; i < len; i += 2) {
		        bKey[i / 2] = (byte) ((Character.digit(input.charAt(i), 16) << 4)
		                             + Character.digit(input.charAt(i+1), 16));
		    }
		    return bKey;
		}

	 
		 /**
		 * deletes a file
		 * @param file
		 */
		 private static void deleteFile(String file) {
			  File f1 = new File(file);
			  f1.delete();
		 }
		 
		 /**
		  * converts a byte array to hex format
		  * @param text in bytes format
		  * @return hex format of the input bytes
		  * @throws IOException
		  */
		 private static String ToHEX(byte[] text) throws IOException{
			 String hexString = "";
			 for(int i = 0; i < text.length; i++)
		 	 {
			 	String hex = Integer.toHexString(text[i]&0xFF );
				if (hex.length() == 1) {
				    hex = "0" + hex;
				}
				hexString = hexString + hex;
			}   
			return hexString;
		 }	
	
	
}
