package com.master.TPM;

import com.master.TPM.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class LogIn extends Activity {

    public EditText editText;
    public String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        editText = (EditText) findViewById(R.id.editText1);

    }

    // get server IP
    public void getIP(View view) {
        text = editText.getText().toString();
        System.out.println(text);
        Intent intent = new Intent(this, KeyVerify.class);
        intent.putExtra("IP", text);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.log_in, menu);
        return true;
    }

}
