package com.master.TPM;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;
// Intent service that receives and sends encrypted files to the PC. 
public class ClientService extends IntentService {
	public final static String EXTRA_MESSAGE = "com.Master.MESSAGE";
	static final int MAX_PACKET_SIZE = 32;
	private int echoServPort=2223; /* Echo server port */
	private int echoClientPort=2228; /* Echo client port */
	private String servIP="172.17.48.174";
	private int packetsToSend=0; /* Number of packets to send */
	private String echoFile;
	private byte[] echoBytes;
	DatagramSocket socket=null;
	public String baseDir = Environment.getExternalStorageDirectory().getAbsolutePath();

	// Constructor methods. 
    public ClientService() {
        super("ClientService");
    }
    public ClientService(String name) {
        super(name);
    }
    // Toasts to let user know the service has started. 
    @Override
    public void onCreate(){
    	super.onCreate();
    	try {
			Class.forName("android.os.AsyncTask");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Toast.makeText(this,"Connecting...", Toast.LENGTH_LONG).show();
    }

   // Once the service is started it calls the Client code to start passing in the Server port, IP, the Client port.
    @Override
    public void onHandleIntent(Intent intent){
    	System.out.println(intent.toString());
    			Client(echoServPort,servIP,echoClientPort,intent);
  
    }
    // This function retrieves the key, and the message to decrypt or encrypt and calls the appropriate functions.
    public void Client(int echoServport,String servIP,int echoClientPort,Intent intent){
    	try {
    		int i=0;
    		byte[] key=intent.getByteArrayExtra("key");
    		String key1 = new String(key);
    	    System.out.println(key1);
    	    String message=intent.getStringExtra("crypto");System.out.println(message);
    		byte[] buffer = new byte[MAX_PACKET_SIZE];
			byte[] buff = key;
			
			//Send the cryptographic key bytes to PC
			socket = new DatagramSocket(echoClientPort);
			DatagramPacket connect = new DatagramPacket(buff,buff.length,InetAddress.getByName(servIP),echoServPort);
			socket.send(connect);
			DatagramPacket expectedPacket = new DatagramPacket(buffer, buffer.length);
			socket.receive(expectedPacket);
			System.out.println("About to listen!");
			
			//send the file pieces back to PC
			if(message.equals("decrypt"))
			{				
				File dir=new File("//storage//emulated//0//DCIM//");
				File[] files=dir.listFiles();
				System.out.println("Num Files:"+files.length);
				for(i=0;i<files.length;i++)
				{
					String fileName=files[i].getName();
					connect(fileName);
					files[i].delete();
				}
				
				buff= new byte[MAX_PACKET_SIZE];
			    ByteArrayOutputStream baos = new ByteArrayOutputStream();
			    DataOutputStream dos = new DataOutputStream(baos);
				dos.writeBytes("Finished");
			    dos.close();
				buff = baos.toByteArray();
				DatagramPacket finishPack=new DatagramPacket(buff,buff.length,InetAddress.getByName(servIP),echoServPort);
				socket.send(finishPack);
				System.out.println("Finished");
			    expectedPacket=new DatagramPacket(buffer, buffer.length);
			    socket.receive(expectedPacket);
			    socket.close();
			    System.out.println("Socket Closed");
	    	}
			else{
				while(!message.contains("Finished")){
					DatagramPacket mess=new DatagramPacket(buffer,buffer.length);
					socket.receive(mess);
					message=new String(mess.getData(),"us-ASCII");
					System.out.println("Message:"+message);
					DatagramPacket messr=new DatagramPacket(buffer,buffer.length, mess.getAddress(), mess.getPort());
					socket.send(messr);
					System.out.println("Sent messr");
					if(!message.contains("Finished"))
					{
						listen();
						System.out.println("Finished with listen.");
					}    
				}
    			
    			socket.close();
    		}
			Bundle bundle = intent.getExtras();
		    if (bundle != null) {
		        Messenger messenger = (Messenger) bundle.get("messenger");
		        Message msg = Message.obtain();
		        Bundle data=new Bundle(1);
		        data.putString("Update","Update");
		        msg.setData(data); //put the data here
		        try {
		            messenger.send(msg);
		        } catch (RemoteException e) {
		            Log.i("error", "error");
		        }
		    }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    // The listen function receives files from the PC and saves them to the app directory. 
    public void listen()
	{
    	try
		{
			byte[] buffer = new byte[MAX_PACKET_SIZE];
			
			//get the number of packets to be sent
			DatagramPacket numPackets=new DatagramPacket(buffer,buffer.length);
			System.out.println("Getting number of packets now");
			socket.receive(numPackets);
			DatagramPacket reply = new DatagramPacket(numPackets.getData(), numPackets.getLength(), numPackets.getAddress(), numPackets.getPort());
			socket.send(reply);
			ByteArrayInputStream bais = new ByteArrayInputStream(numPackets.getData());
			DataInputStream dis = new DataInputStream(bais);
			int packNum = dis.readInt();
			System.out.println("numPackets: " + packNum);
			
			//get the filename of the packets being sent
			String fileName = "";
			buffer = new byte[MAX_PACKET_SIZE];
			DatagramPacket arrivalPacket = new DatagramPacket(buffer,buffer.length);
			socket.receive(arrivalPacket);
			fileName = new String(arrivalPacket.getData(),"us-ASCII");
			System.out.println("Filename is:"+fileName);
			reply = new DatagramPacket(arrivalPacket.getData(), arrivalPacket.getLength(), arrivalPacket.getAddress(), arrivalPacket.getPort());
			socket.send(reply);
			
			byte[]	data=new byte[MAX_PACKET_SIZE*packNum];
			int dataIndex=0;
			//get the contents of the file being sent
			for(int i = 0; i < packNum; i++)
			{
				buffer = new byte[MAX_PACKET_SIZE];
				arrivalPacket = new DatagramPacket(buffer,buffer.length);
				socket.receive(arrivalPacket);
				for(int j=0;j<MAX_PACKET_SIZE;j++){
					data[dataIndex]=buffer[j];
					dataIndex++;
				}
				// create and send response packet
				reply = new DatagramPacket(arrivalPacket.getData(), arrivalPacket.getLength(), arrivalPacket.getAddress(), arrivalPacket.getPort());
				socket.send(arrivalPacket);
			}
			System.out.println("Filename:"+fileName);
			//display message saying file received
			fileName = fileName.replaceAll("\\..*","");
			fileName+=".piece";
			System.out.println("FileName changed is:"+fileName);
		
			File folder=new File("//storage//emulated//0//DCIM//"+fileName);
			folder.createNewFile();
			FileOutputStream fos = null;
			fos = new FileOutputStream(folder);
			fos.write(data);
			fos.flush();
			fos.close();
			Toast.makeText(this,"File Received:"+ fileName, Toast.LENGTH_LONG).show();
		}
		catch (SocketException e)
		{
			System.err.println("Error creating the server socket: " + e.getMessage());
		}
		catch (IOException e)
		{
			System.err.println("Server socket Input/Output error: " + e.getMessage());
		}
	}
    // This function sets the filename, the Client/Server ports, and the Server IP and calculates how many packets are in the 
    // data to be sent to the PC. 
	public void Client(int echoServPort, String servIP, int echoClientPort, File fileName) 
	{
    	this.echoServPort = echoServPort;
    	this.echoClientPort = echoClientPort;
    	this.servIP = servIP;
    	this.echoFile = fileName.getName();
    
		this.echoBytes =read(fileName.getPath());

    	if(this.echoBytes.length%MAX_PACKET_SIZE==0)
    	{
    		this.packetsToSend = this.echoBytes.length/MAX_PACKET_SIZE;
    	}
    	else
    	{
    		this.packetsToSend = (this.echoBytes.length/MAX_PACKET_SIZE)+1;
    	}
    }

    		/**
    		* Sends packets to the client PC and reads the responses.
    		*/
    		public void send()
    		{
    			try
    			{
    				System.out.println("Sending");
    				byte[] buffer = new byte[MAX_PACKET_SIZE];
    				final ByteArrayOutputStream baos = new ByteArrayOutputStream();
    		        final DataOutputStream dos = new DataOutputStream(baos);
    		        dos.writeInt(packetsToSend);
    		        dos.close();
    				byte[] buff = baos.toByteArray();
    				final ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
    				final DataOutputStream dos2 = new DataOutputStream(baos2);
    				dos2.write(echoFile.getBytes("us-ASCII"));
    		        dos2.close();
    				byte[] fileName =baos2.toByteArray(); 
    				if (packetsToSend >= 1) 
    				{
    					int c=0;
    					DatagramPacket mess=new DatagramPacket(buffer,buffer.length,InetAddress.getByName(servIP),echoServPort);
    					socket.send(mess);
    					DatagramPacket expmess=new DatagramPacket(buffer,buffer.length);
    					socket.receive(expmess);
    					DatagramPacket numPackets = new DatagramPacket(buff,buff.length,InetAddress.getByName(servIP),echoServPort);
    					socket.send(numPackets);
    					System.out.println("Packets to send:"+packetsToSend);
    					DatagramPacket expectedPacket = new DatagramPacket(buffer, buffer.length);
    					socket.receive(expectedPacket);
    					System.out.println("Expected reply:" + (new String(expectedPacket.getData(),"us-ASCII")));
    					DatagramPacket nameFile = new DatagramPacket(fileName,fileName.length,InetAddress.getByName(servIP),echoServPort);
    					socket.send(nameFile);
    					System.out.println((new String(nameFile.getData(),"us-ASCII")));
    					expectedPacket = new DatagramPacket(buffer, buffer.length);
    					socket.receive(expectedPacket);
    					for(int i=0;i<echoBytes.length;i++){
    						buffer[c] = echoBytes[i];
    						c++;
    						if(c==MAX_PACKET_SIZE){
    							DatagramPacket requestPacket = new DatagramPacket(buffer,buffer.length,InetAddress.getByName(servIP),echoServPort);
    							socket.send(requestPacket);
								buffer = new byte[MAX_PACKET_SIZE];
    							c=0;
    							expectedPacket = new DatagramPacket(buffer, buffer.length);
    							socket.receive(expectedPacket);
    							buffer = new byte[MAX_PACKET_SIZE];
    						}
    					}

    				}

    			}
    			catch (SocketException e)
    			{
    				System.err.println("Error creating the client socket: " + e.getMessage());
    			}
    			catch (IOException e)
    			{
    				System.err.println("Client socket Input/Output error: " + e.getMessage());
    			}

    		}
    		// Reads the contents of files into a byte array to be sent to the PC in datagram packets. 
    		public static byte[] read(String aInputFileName){
    		    File file = new File(aInputFileName);
    		    
    		    byte[] result = new byte[(int)file.length()];
    		    try {
    		      InputStream input = null;
    		     
    		        int totalBytesRead = 0;
    		        input = new BufferedInputStream(new FileInputStream(file));
    		        while(totalBytesRead < result.length){
    		          int bytesRemaining = result.length - totalBytesRead;
    		          //input.read() returns -1, 0, or more :
    		          int bytesRead = input.read(result, totalBytesRead, bytesRemaining); 
    		          if (bytesRead > 0){
    		            totalBytesRead = totalBytesRead + bytesRead;
    		          
    		        }
    		        /*
    		         the above style is a bit tricky: it places bytes into the 'result' array; 
    		         'result' is an output parameter;
    		         the while loop usually has a single iteration only.
    		        */
    		      
    		        }
    		        input.close();
    		      
    		    } catch (FileNotFoundException ex) {
    		    } catch (IOException ex) {
    		    }
    		    return result;
    		  }
    		
// Connect function sets file name and calls client and sending functions. 
    		public void connect(String fileName)
    		{
    		
    			File _echoFile =new File("//storage//emulated//0//DCIM//"+fileName); /* String to send to echo server */
    			Client(echoServPort, servIP, echoClientPort, _echoFile);
    			System.out.println("About to send...");
    			send();

    		}
    	
    	}