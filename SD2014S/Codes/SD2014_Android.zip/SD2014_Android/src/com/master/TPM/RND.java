package com.master.TPM;


import java.security.SecureRandom;
import java.sql.Date;
import java.text.DateFormat;
import java.util.Random;
import java.util.TimeZone;
import java.security.NoSuchAlgorithmException;

// This class generates salts and keys. 
public class RND {
	private long salt = 0;
	private String s="";
	// Constructor methods. 
	public RND(String password){
		this.s=password;
	}
    public RND(){
    	
    }
// Generates a key using SHA1PRNG with the system time in nanoseconds as a seed and concatenates it with the salt. 
	public byte[] getRandom() throws NoSuchAlgorithmException{
	Random random=null;
	byte [] testrngrn=null;
	random = SecureRandom.getInstance("SHA1PRNG");
	long nanoGMT2 = System.nanoTime();
	for (int i=0; i<4; i++)
	{
		random.setSeed(nanoGMT2);
		salt = random.nextLong();	
	}
	addSalt();
	for (int i=0; i<4; i++)
	{
		
		random.setSeed(nanoGMT2+salt);
		testrngrn = new byte [32];
		random.nextBytes(testrngrn);
	}
	
	return testrngrn;
	}
	// Turns a byte array into a hex string. 
	public static String byteArrayToHexString(byte[] b) 
	{
	    try{
	        StringBuffer sb = new StringBuffer(b.length * 2);
	        for (int i = 0; i < b.length; i++)
	        {
	            int v = b[i] & 0xff;
	            if (v < 16) 
	            {
	                sb.append('0');
	            }
	            sb.append(Integer.toHexString(v));
	        }
	        return sb.toString().toUpperCase();
	    }
	    catch(NullPointerException npe){return "(null)";}
	}
	//Returns system time as a string. 
	public static String GetTime()
	{
		Date date = new Date(0);
		DateFormat dateFormat = DateFormat.getDateTimeInstance( DateFormat.LONG, DateFormat.LONG );  
		TimeZone zone = dateFormat.getTimeZone();
		zone = TimeZone.getTimeZone("GMT");
		dateFormat.setTimeZone( zone );
		String GMT_Time = dateFormat.format(date); 
		return GMT_Time;
		
	}
// Takes the hash of the password and adds the salt to it. 
		public void addSalt(){
		
			char[] sA = s.toCharArray();
			long strConv = 0;
			for(int i = 0; i < sA.length; i++)
			{
				strConv += sA[i];
			}
			
			//adds the randomly generated salt to the long representation of the password hash
			salt = salt + strConv;
		}
	
}

