package com.master.TPM;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import java.util.*;
import client.*;

// Intent service that receives and sends encrypted files to the PC. 
public class NetworkService extends IntentService {
    private ArrayList<String> text;
    private Client client;
    private static String serverAddr = "10.0.2.2";

    // Constructor methods.
    public NetworkService() {
        super("networkservice");
    }

    public NetworkService(String name) {
        super(name);
    }

    // Toasts to let user know the service has started.
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            Class.forName("android.os.AsyncTask");
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        Toast.makeText(this, "Connecting...", Toast.LENGTH_LONG).show();
    }

    // Once the service is started it calls the Client code to start passing in
    // the Server port, IP, the Client port.
    @Override
    public void onHandleIntent(Intent intent) {
        System.out.println(intent.toString());
        serverAddr = intent.getStringExtra("IP");
        text = intent.getStringArrayListExtra("text");
        client = new Client(serverAddr, "127.0.0.1", false);
        for(String character : text) {
            client.sendCharacter(character);
        }
        client.finishLogin();
    }
}
