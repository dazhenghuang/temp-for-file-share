package com.master.TPM;
//import java.rmi.*;

public interface AndrFeedbackInt {//extends Remote {
	//public void hash1(String mess) throws RemoteException;
//	public void hash2(String mess) throws RemoteException;
	public void hash3(String mess);// throws RemoteException;
	public void hash4(String mess);// throws RemoteException;
//	public byte[] getHash1() throws RemoteException;
//	public byte[] getHash2() throws RemoteException;
	public String getHash3();// throws RemoteException;
	public String getHash4();// throws RemoteException;
}