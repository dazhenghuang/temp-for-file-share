package com.master.TPM;

import java.io.File;

import javax.crypto.SecretKey;

/**
 * @author Caleb Schwind
 */
public interface AndroidSecurityInt {
	

	/**Encrypts messages or obfuscated password
	 * 
	 * @param obfuscated password
	 * @param encryption key
	 * @param IV output filename+path
	 * @return encrypted obfuscated password
	 */
	byte[] encryptMessage(byte[] message, SecretKey key, String IVOut);
	
	/**Decrypts messages or obfuscated password
	 * 
	 * @param encrypted obfuscated password
	 * @param decryption key
	 * @param filename of the IV
	 * @param True for IV false for IV file path
	 * @return decrypted obfuscated password
	 */
	byte[] decryptMessage(byte[] encrMessage, SecretKey key, String IVin, boolean isIV);
	
	
	SecretKey getSecureChannelKey(byte[] seed1, byte[] seed2, String pressedKey);
	
	/**
	 * Generates a random key as byte array
	 * @return random key as byte array
	 */
	byte[] getRandomKey();
	
	/**
	 * Writes the seeds to USB/SD
	 * 
	 * @param current login seed
	 * @param next login seed
	 * @param filename + path to save seeds
	 */
	void writeSeeds(byte[] seed1, byte[] seed2, String filename);
	
	/**
	 * Gets the seeds from the USB/SD.
	 * 
	 * @param filename + path to read seeds
	 * @return seeds seperated by a comma
	 */
	String getSeeds(String filename);
	
	/**
	 * Converts long to byte[] for dealing with seeds of long type.
	 * 
	 * @param seed of type long
	 * @return seed of type byte[]
	 */
	byte[] long2byte(long l);
}
